define("ace/snippets/nunjucks",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="nunjucks"});                (function() {
                    window.require(["ace/snippets/nunjucks"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            