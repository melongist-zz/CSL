define("ace/snippets/html_elixir",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="html_elixir"});                (function() {
                    window.require(["ace/snippets/html_elixir"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            