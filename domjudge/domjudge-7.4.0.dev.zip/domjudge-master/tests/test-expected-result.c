/*
 * This should fail with NO-OUTPUT.
 *
 * @EXPECTED_RESULTS@: NO-OUTPUT
 */

int main()
{
	return 0;
}
