/*
 * Sample solution in C for the "boolfind" interactive problem.
 * Exits immediately without any output.
 *
 * @EXPECTED_RESULTS@: NO-OUTPUT
 */

int main()
{
	return 0;
}
