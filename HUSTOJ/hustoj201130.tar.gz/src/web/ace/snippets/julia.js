ace.define("ace/snippets/julia",[], function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "julia";

});
                (function() {
                    ace.require(["ace/snippets/julia"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            