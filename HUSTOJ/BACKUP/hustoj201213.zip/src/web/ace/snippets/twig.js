ace.define("ace/snippets/twig",[], function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "twig";

});
                (function() {
                    ace.require(["ace/snippets/twig"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            