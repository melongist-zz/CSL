<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>娱乐 - MasterOJ</title>
        <?php require( "./template/bshark/header-files.php");?>
    </head>
    
    <body>
        <?php require( "./template/bshark/nav.php");?>
        <div class="row" style="margin: 3% 8% 5% 8%">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <h4>娱乐<small>此页面会不断更新</small></h4>
                        <b>说明：此页面将会不断优化用户体验，也会不断开发。欢迎给我们材料，包括html5小游戏，自己写的游戏程序，还有改编的游戏，也可上传游戏视频，联系yemaster（qq1440169768)</b>
                        <h5>在线html5小游戏</h5>
                        <ol>
                            <li><a href="games/flappy_bird/">Flappy Bird</a></li>
                            <li><a href="games/2048/">2048</a></li>
                            <li><a href="games/flappy_2048/">Flappy 2048</a></li>
                        </ol>
                        因为后面要iframe，所以暂时这样
                        <h5>游戏视频</h5>
                    </div>
                </div>
            </div>
        </div>
        <?php require( "./template/bshark/footer.php");?>
        <?php require( "./template/bshark/footer-files.php");?>
    </body>

</html>