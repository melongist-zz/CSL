<footer align=center>
            <p>GPLv2 licensed by <a href='https://github.com/zhblue/hustoj' >HUSTOJ</a> <?php echo date('Y');?><br>
            THEME bshark by <a href="https://github.com/yemaster">yemaster</a>.
            
            </p>
</footer>
