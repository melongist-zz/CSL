apt-get install docker.io
docker build -t hustoj .

