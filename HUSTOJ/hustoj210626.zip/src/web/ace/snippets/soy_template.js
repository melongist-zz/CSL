ace.define("ace/snippets/soy_template",[], function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "soy_template";

});
                (function() {
                    ace.require(["ace/snippets/soy_template"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            