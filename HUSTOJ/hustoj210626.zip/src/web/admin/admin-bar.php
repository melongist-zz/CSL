	<div class="navbar">
	 	<div class="navbar-inner navbar-fixed-top" style="visibility: visible; position: fixed;">
	 		<a  class='brand'  href="<?php echo $OJ_HOME?>">
				ADMIN PANEL					
			</a>
			<div class="nav-collapse"><ul class="nav pull-right"><li class="return"><a href="../">Return</a></li></ul></div>
		</div>
	</div>
