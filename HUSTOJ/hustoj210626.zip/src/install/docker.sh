apt-get install -y docker.io
docker build -t hustoj .

