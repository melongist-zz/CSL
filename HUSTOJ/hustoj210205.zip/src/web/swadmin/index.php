<?php
//$cur_path = "template/$OJ_TEMPLATE/";
//$dir=basename(getcwd());
//echo $cur_path;
//echo $dir;
//?>
<!--<html>-->
<!--<head>-->
<!--  <title>JudgeOnline Administration</title>-->
<!--    <link rel="stylesheet" href="layui/css/layui.css">-->
<!--    <script src="layui/layui.js"></script>-->
<!--</head>-->
<!--<frameset cols="20%,*">-->
<!--  <frame name="menu" src="menu.php">-->
<!--  <frame name="main" src="help.php">-->
<!--  <noframes>-->
<!--  </noframes>-->
<!--</frameset>-->
<!--<body>-->
<!--<div style="display: flex;flex-direction: row">-->
<!--    <div style="display: flex">-->
        <?php include("swmenu.php");?>
<!--    </div>-->
<!--    <div><div style="width: 300px;height: 300px;background-color: #0e90d2"></div></div>-->
<!--</div>-->

<!--<ul class="layui-nav layui-nav-tree layui-nav-side" lay-filter="">-->
<!--    <li class="layui-nav-item"><a href="">最新活动</a></li>-->
<!--    <li class="layui-nav-item layui-this"><a href="">产品</a></li>-->
<!--    <li class="layui-nav-item"><a href="">大数据</a></li>-->
<!--    <li class="layui-nav-item">-->
<!--        <a href="javascript:;">解决方案</a>-->
<!--        <dl class="layui-nav-child"> <!-- 二级菜单 -->-->
<!--            <dd><a href="">移动模块</a></dd>-->
<!--            <dd><a href="">后台模版</a></dd>-->
<!--            <dd><a href="">电商平台</a></dd>-->
<!--        </dl>-->
<!--    </li>-->
<!--    <li class="layui-nav-item"><a href="">社区</a></li>-->
<!--</ul>-->
<!---->
<!--<script>-->
<!--    //注意：导航 依赖 element 模块，否则无法进行功能性操作-->
<!--    layui.use('element', function(){-->
<!--        var element = layui.element;-->
<!---->
<!--        //…-->
<!--    });-->
<!--</script>-->
<!--</body>-->
<!--</html>-->
