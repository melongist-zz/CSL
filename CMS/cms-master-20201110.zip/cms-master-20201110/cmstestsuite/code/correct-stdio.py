import sys

n = int(sys.stdin.readline().strip())
sys.stdout.write("correct %d\n" % n)
