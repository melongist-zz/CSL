public class user1 {

    public static int userfunc1(int x) {
        return x;
    }

}
