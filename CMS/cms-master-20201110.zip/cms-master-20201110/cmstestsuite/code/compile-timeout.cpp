#include __FILE__
#include __FILE__
int main(){f();}
