using System;

public static class Batchstdio
{
    public static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        Console.WriteLine("correct " + n);
        Environment.Exit(1);
    }
}
