using System;

public static class Batchfileio
{
    public static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        Console.WriteLine("correct " + n);
    }
}
