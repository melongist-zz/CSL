int main() {
    Is my time up yet?
}
