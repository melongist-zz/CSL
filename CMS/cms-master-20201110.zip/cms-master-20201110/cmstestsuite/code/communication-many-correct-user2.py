def userfunc2(x):
    return -x
