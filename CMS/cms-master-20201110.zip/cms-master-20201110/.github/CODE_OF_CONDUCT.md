# Code of conduct

We endorse and follow the code of conduct of the International Olympiad of Informatics, available at the [IOI website](https://ioinformatics.org/page/code-of-conduct).


