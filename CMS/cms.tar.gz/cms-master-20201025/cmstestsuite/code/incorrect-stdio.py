import sys

n = int(sys.stdin.readline().strip())
sys.stdout.write("incorrect %d\n" % n)
