#include "manager.h"

int userfunc2(int x) {
    return x;
}
