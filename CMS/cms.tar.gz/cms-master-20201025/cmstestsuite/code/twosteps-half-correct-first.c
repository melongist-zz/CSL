#include "manager.h"

int userfunc1(int x) {
    return x % 2 ? x : 0;
}
