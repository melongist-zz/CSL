def userfunc2(x):
    return -x + 1
