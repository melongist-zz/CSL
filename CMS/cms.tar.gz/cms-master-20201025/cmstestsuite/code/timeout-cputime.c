#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    printf("correct %d\n", n);
    fflush(stdout);
    while(1);
    return 0;
}
