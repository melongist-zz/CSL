#include "manager.h"

int userfunc1(int x) {
    return 0;
}
