import java.util.Scanner;

public class batchfileio {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        System.out.println("correct "+n);
    }
}
