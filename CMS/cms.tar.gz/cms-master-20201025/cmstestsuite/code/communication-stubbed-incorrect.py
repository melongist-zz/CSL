def userfunc(x):
    return x + 1
